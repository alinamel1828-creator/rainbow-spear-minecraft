scoreboard objectives add r_dash dummy
scoreboard objectives add r_hit dummy
scoreboard objectives add r_shield dummy
scoreboard objectives add r_cage dummy
scoreboard objectives remove r_hp
scoreboard objectives add r_hp dummy
scoreboard objectives add r_sneak minecraft.custom:minecraft.sneak_time
recipe give @a rainbow:rainbow_spear
tellraw @a {"text":"[RainbowSpear 2.0] Все 6 способностей и сверхчары активированы!","color":"light_purple"}

