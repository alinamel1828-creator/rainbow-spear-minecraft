scoreboard players add @a r_dash 0
scoreboard players add @a r_hit 0
scoreboard players add @a r_shield 0
scoreboard players remove @a[scores={r_dash=1..}] r_dash 1
scoreboard players remove @a[scores={r_hit=1..}] r_hit 1
scoreboard players remove @a[scores={r_shield=1..}] r_shield 1

# Читаем точное ХП каждого игрока каждый тик
execute as @a store result score @s r_hp run data get entity @s Health

# Способность 1 (Работает из ЛЮБОГО слота инвентаря!): Скорость II + Прыгучесть II + радужный шлейф
execute as @a if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] at @s run effect give @s minecraft:speed 1 1 true
execute as @a if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] at @s run effect give @s minecraft:jump_boost 1 1 true
execute as @a if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] at @s run particle minecraft:dust{color:[1.0,0.2,0.2],scale:1.2} ~ ~0.8 ~ 0.3 0.3 0.3 0 1
execute as @a if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] at @s run particle minecraft:dust{color:[0.2,1.0,0.4],scale:1.2} ~ ~1.1 ~ 0.3 0.3 0.3 0 1
execute as @a if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] at @s run particle minecraft:dust{color:[0.4,0.4,1.0],scale:1.2} ~ ~1.4 ~ 0.3 0.3 0.3 0 1
execute as @a if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] at @s run particle minecraft:end_rod ~ ~1 ~ 0.4 0.5 0.4 0.02 1

# Способность 2 (В руке + Shift): Радужный рывок
execute as @a[scores={r_sneak=1..}] if items entity @s weapon.mainhand minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] if score @s r_dash matches ..0 at @s run function rainbow:dash
scoreboard players set @a[scores={r_sneak=1..}] r_sneak 0

# Способность 5 (Работает из ЛЮБОГО слота инвентаря!): Спас-щит при ХП <= 8 (4 сердца) на 10 секунд
execute as @a[scores={r_hp=1..8}] if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] if score @s r_shield matches ..0 at @s run function rainbow:panic_shield

# Таймер очистки квадратика 2x2 изумрудных блоков и паутины (через 4 секунды)
scoreboard players remove @e[type=minecraft:marker,tag=r_cage_marker,scores={r_cage=1..}] r_cage 1
execute as @e[type=minecraft:marker,tag=r_cage_marker,scores={r_cage=0}] at @s run fill ~ ~-1 ~ ~1 ~1 ~1 minecraft:air replace minecraft:emerald_block
execute as @e[type=minecraft:marker,tag=r_cage_marker,scores={r_cage=0}] at @s run fill ~ ~ ~ ~1 ~1 ~1 minecraft:air replace minecraft:cobweb
kill @e[type=minecraft:marker,tag=r_cage_marker,scores={r_cage=0}]

