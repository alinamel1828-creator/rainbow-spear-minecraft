execute at @s positioned ^ ^1.2 ^2.2 run particle minecraft:enchant ~ ~ ~ 0.6 0.6 0.6 0.5 35
execute at @s positioned ^ ^1.2 ^2.2 run particle minecraft:crit ~ ~ ~ 0.5 0.5 0.5 0.2 20
advancement revoke @s only rainbow:hit_enemy

# Баффы при ударе: Сила II тебе на 10 сек + Замедление IV поражённому врагу на 5 сек
effect give @s minecraft:strength 10 1 true
execute at @s as @e[distance=0.5..7,nbt={HurtTime:10s}] run effect give @s minecraft:slowness 5 3 true

# Если бьёшь в прыжке/падении — эффект Радужного Слэма
execute if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"flags":{"is_on_ground":false}}} at @s positioned ^ ^ ^2.5 run particle minecraft:explosion_emitter ~ ~ ~ 0.5 0.5 0.5 0 1
execute if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"flags":{"is_on_ground":false}}} at @s positioned ^ ^ ^2.5 run playsound minecraft:item.mace.smash_ground player @a ~ ~ ~ 1 1.1

# Раз в 4 секунды: Молния + квадрат 2x2 изумрудных блоков и паутины строго под ударенным врагом!
execute if score @s r_hit matches ..0 at @s as @e[distance=0.5..7,nbt={HurtTime:10s},limit=1] at @s run summon minecraft:lightning_bolt ~ ~ ~
execute if score @s r_hit matches ..0 at @s as @e[distance=0.5..7,nbt={HurtTime:10s},limit=1] at @s run fill ~ ~-1 ~ ~1 ~-1 ~1 minecraft:emerald_block replace #minecraft:replaceable
execute if score @s r_hit matches ..0 at @s as @e[distance=0.5..7,nbt={HurtTime:10s},limit=1] at @s run fill ~ ~ ~ ~1 ~1 ~1 minecraft:cobweb replace minecraft:air
execute if score @s r_hit matches ..0 at @s as @e[distance=0.5..7,nbt={HurtTime:10s},limit=1] at @s run summon minecraft:marker ~ ~ ~ {Tags:["r_cage_marker"]}
execute if score @s r_hit matches ..0 at @s as @e[distance=0.5..7,nbt={HurtTime:10s},limit=1] at @s run scoreboard players set @e[type=minecraft:marker,tag=r_cage_marker,distance=..1] r_cage 80
execute if score @s r_hit matches ..0 run scoreboard players set @s r_hit 80

