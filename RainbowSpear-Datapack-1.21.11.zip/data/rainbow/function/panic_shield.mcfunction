scoreboard players set @s r_shield 400
effect give @s minecraft:resistance 10 2 true
effect give @s minecraft:regeneration 6 1 true
playsound minecraft:item.shield.block player @s ~ ~ ~ 1 0.8
particle minecraft:totem_of_undying ~ ~1 ~ 0.6 0.6 0.6 0.2 30
title @s actionbar {"text":"🛡️ Щит Призмы активирован на 10 сек!","color":"aqua"}

