scoreboard players set @s r_dash 60
playsound minecraft:entity.breeze.wind_burst player @s ~ ~ ~ 1 1.3
particle minecraft:note ~ ~1 ~ 0.6 0.6 0.6 1 25
execute anchored eyes positioned ^ ^ ^0.5 run summon minecraft:wind_charge ~ ~ ~ {Motion:[0.0,-0.4,0.0]}
particle minecraft:sonic_boom ^ ^1 ^2 0 0 0 0 1
particle minecraft:totem_of_undying ~ ~1 ~ 0.5 0.5 0.5 0.3 25

