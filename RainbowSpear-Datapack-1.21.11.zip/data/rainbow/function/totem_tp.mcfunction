advancement revoke @s only rainbow:totem_pop
execute if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] at @s run playsound minecraft:item.chorus_fruit.teleport player @a ~ ~ ~ 1 1
execute if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] at @s run particle minecraft:portal ~ ~1 ~ 0.8 1 0.8 0.5 40
execute if items entity @s container.* minecraft:netherite_spear[minecraft:custom_data~{rainbow_spear:true}] at @s run spreadplayers ~ ~ 20 50 false @s

